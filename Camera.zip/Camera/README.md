# Custom Camera
 - With Auto Focus functionality.
 - Switch Camera
