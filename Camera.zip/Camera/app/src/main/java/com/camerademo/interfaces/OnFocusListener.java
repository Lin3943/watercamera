package com.camerademo.interfaces;

/**
 * Created by xy on 22/2/16.
 */
public interface OnFocusListener {
    void onFocused();
}
