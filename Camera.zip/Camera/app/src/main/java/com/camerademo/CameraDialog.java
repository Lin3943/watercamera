package com.camerademo;

import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.hardware.Camera;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.camerademo.interfaces.OnFocusListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 创建人：xy
 * 创建日期：2016/11/7.
 * 功能描述：
 */

public class CameraDialog extends Fragment implements OnFocusListener {

    private Camera mCamera;
    private CameraPreview mCameraPreview;
    private int currentCameraId;
    private Button mTakePhoto;
    private EditText mInputText;
    private OrientationEventListener mOrientationListener;
    private int orientations;

    public CameraDialog() {
    }

    @Override
    public void onResume() {
        super.onResume();
        mOrientationListener = new OrientationEventListener(getActivity()){
            @Override
            public void onOrientationChanged(int orientation) {
                //获取重力方向，PS：可以将orientations相关的去掉对比效果
                orientations =orientation;
                Log.e("onResume", "现在是横屏"+orientation);
            }
        };
        if(mOrientationListener!=null){//先判断下防止出现空指针异常
            mOrientationListener.enable();
        }

//        Log.e("onResume: ",cameraOrientation+"" );
        mCamera = getCameraInstance(currentCameraId);
//        mCamera.setDisplayOrientation(270);  //设置拍出的图不会横屏
//        Log.e("camera90： ", "旋转旋转啊...90");
        mCameraPreview = new CameraPreview(getActivity(), this, mCamera);
        FrameLayout preview = (FrameLayout) getActivity().findViewById(R.id.save_photo);
        preview.addView(mCameraPreview);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mRootView = inflater.inflate(R.layout.camera_dialog_fragment, null);
        mTakePhoto = (Button) mRootView.findViewById(R.id.take_photo);
        mInputText = (EditText) mRootView.findViewById(R.id.inputText);

        return mRootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //判断相机正反摄像头
        if (getActivity().getIntent().hasExtra("camera_id")) {
            currentCameraId = getActivity().getIntent().getIntExtra("camera_id", Camera.CameraInfo.CAMERA_FACING_BACK);
        } else {
            currentCameraId = Camera.CameraInfo.CAMERA_FACING_BACK;
        }

        //拍照
        mTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                v.setEnabled(false);
                takePhoto1();
            }
        });
        // LIN 2016/11/8 :切换主副镜头
//        switchCameraButton = (Button) getActivity().findViewById(R.id.button_switch_camera);
//        switchCameraButton.setVisibility(
//                Camera.getNumberOfCameras() > 1 ? View.VISIBLE : View.GONE);
//        switchCameraButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mCamera.stopPreview();
//                //NB: if you don't release the current camera before switching, you app will crash
//                mCameraPreview.getHolder().removeCallback(mCameraPreview);
//                mCamera.release();
//
//                //swap the id of the camera to be used
//                if (currentCameraId == Camera.CameraInfo.CAMERA_FACING_BACK) {
//                    currentCameraId = Camera.CameraInfo.CAMERA_FACING_FRONT;
//                } else {
//                    currentCameraId = Camera.CameraInfo.CAMERA_FACING_BACK;
//                }
//
//                mCamera = getCameraInstance(currentCameraId);
//                mCameraPreview = new CameraPreview(getActivity(), mCamera);
//                FrameLayout preview = (FrameLayout) getActivity().findViewById(R.id.save_photo);
//                preview.removeAllViews();
//                preview.addView(mCameraPreview);
//            }
//        });
    }

    private void takePhoto1() {
        // Obtain MotionEvent object
        mCameraPreview.setNeedToTakePic(true);
        long downTime = SystemClock.uptimeMillis();
        long eventTime = SystemClock.uptimeMillis() + 100;
        float x = mCameraPreview.getWidth() / 2;
        float y = mCameraPreview.getHeight() / 2;
        // List of meta states found here:
        // developer.android.com/reference/android/view/KeyEvent.html#getMetaState()
        //正反摄像头状态
        int metaState = 0;
        //聚焦
        MotionEvent motionEvent = MotionEvent.obtain(
                downTime,
                eventTime,
                MotionEvent.ACTION_DOWN,
                x,
                y,
                metaState
        );
        // Dispatch touch event to view
        mCameraPreview.dispatchTouchEvent(motionEvent);
    }

    /**
     * Helper method to access the camera returns null if it cannot get the
     * camera or does not exist
     * 判断相机是否存在，存在则获取实例
     *
     * @return
     */
    private Camera getCameraInstance(int currentCameraId) {
        Camera camera = null;
        try {
            camera = Camera.open(currentCameraId);
        } catch (Exception e) {
            // cannot get camera or does not exist
        }
        return camera;
    }

    Camera.PictureCallback mPicture = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            File pictureFile = getOutputMediaFile();
            if (pictureFile == null) {
                return;
            }
            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                Bitmap picture = compressBitmap(data, 1920, 1080);
                addWaterMark(picture).compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                fos.write(byteArray);
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };

    private Bitmap addWaterMark(Bitmap picture) {
        int width = picture.getWidth();
        int height = picture.getHeight();
        Bitmap newBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas mCanvas = new Canvas(newBitmap);
        // 往位图中开始画入picture原始图片
        mCanvas.drawBitmap(picture, 0, 0, null);
        // 开始加入文字
        mCanvas.save(Canvas.ALL_SAVE_FLAG);//保存当前画布状态

        String string = mInputText.getText().toString();
        if (null != string) {
            Paint textPaint = new Paint();
            textPaint.setColor(Color.RED);
            textPaint.setTextSize(100);
            textPaint.setAlpha(128);
            String familyName = "宋体";
            Typeface typeface = Typeface.create(familyName,
                    Typeface.BOLD_ITALIC);
            textPaint.setTypeface(typeface);
            textPaint.setTextAlign(Paint.Align.CENTER);
            //设置文字位置
            mCanvas.drawText(string, width / 2, height / 2, textPaint);
        }

        mCanvas.restore();
        return newBitmap;
    }

    //
    private static File getOutputMediaFile() {
        File mediaStorageDir = new File(
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DCIM),
                "MyCamera");
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("MyCamera", "failed to create directory");
                return null;
            }
        }
        File mediaFile;
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + "IMG_" + getStringToday() + ".jpg");
        if (mediaFile.exists()) mediaFile.delete();

        return mediaFile;
    }

    @Override
    public void onFocused() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                mCamera.takePicture(null, null, mPicture);
                takePhoto();
                mCameraPreview.setNeedToTakePic(false);
            }
        }, 1500);
    }

    private void takePhoto() {
        if (mCamera != null) {
            Camera.Parameters cameraParameter = mCamera.getParameters();
            cameraParameter.setRotation(90);
            cameraParameter.set("rotation", 90);
            if ((orientations >= 45) && (orientations < 135)) {
                cameraParameter.setRotation(180);
                cameraParameter.set("rotation", 180);
            }
            if ((orientations >= 135) && (orientations < 225)) {
                cameraParameter.setRotation(270);
                cameraParameter.set("rotation", 270);
            }
            if ((orientations >= 225) && (orientations < 315)) {
                cameraParameter.setRotation(0);
                cameraParameter.set("rotation", 0);
            }
            mCamera.setParameters(cameraParameter);
            mCamera.takePicture(null, null, mPicture);
            Log.e("takePhoto: ",orientations+"" );
        }
    }

    /**
     * 得到现在时间
     * 格式化时间
     *
     * @return 字符串 yyyyMMdd_HHmmss
     */
    public static String getStringToday() {
        Date currentTime = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String dateString = formatter.format(currentTime);
        return dateString;
    }


    /**
     * 压缩指定byte[]图片，并得到压缩后的图像
     *
     * @param bts
     * @param reqsW
     * @param reqsH
     * @return
     */
    public final static Bitmap compressBitmap(byte[] bts, int reqsW, int reqsH) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bts, 0, bts.length, options);
        options.inSampleSize = caculateInSampleSize(options, reqsW, reqsH);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(bts, 0, bts.length, options);
    }

    /**
     * caculate the bitmap sampleSize
     * 创建压缩长度的图片
     *
     * @param options
     * @return
     */
    public final static int caculateInSampleSize(BitmapFactory.Options options, int rqsW, int rqsH) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (rqsW == 0 || rqsH == 0) {
            return 1;
        }
        if (height > rqsH || width > rqsW) {
            final int heightRatio = Math.round((float) height / (float) rqsH);
            final int widthRatio = Math.round((float) width / (float) rqsW);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        return inSampleSize;
    }

    // LIN 2016/11/10 :将文件目录下的图片旋转至匹配手机屏幕的视图
//    private void changeDisplay() {
//        File pictureFile = getOutputMediaFile();
//        BitmapFactory.Options options = new BitmapFactory.Options();
//        options.inSampleSize = 2;//将图片缩略之1/2
//        options.inJustDecodeBounds = true;
//        int degree = readPictureDegree(pictureFile.getPath());
//        Bitmap picture = BitmapFactory.decodeFile(pictureFile
//                .getPath(),options);
//        Bitmap newPicture = rotaingImageView(degree,picture);//旋转
//    }


    /**
     * 读取图片属性：旋转的角度
     *
     * @param path 图片绝对路径
     * @return degree旋转的角度
     */
    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }

    /**
     * 旋转图片
     *
     * @param angle
     * @param bitmap
     * @return Bitmap
     */
    public static Bitmap rotaingImageView(int angle, Bitmap bitmap) {
        Bitmap resizedBitmap = null;
        //旋转图片 动作
        Matrix matrix = new Matrix();
        ;
        matrix.postRotate(angle);
        // 创建新的图片
        try {
            resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0
                    , bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        } catch (OutOfMemoryError e) {
        }
        if (resizedBitmap == null) {
            resizedBitmap = bitmap;
        }
        if (bitmap != resizedBitmap) {
            bitmap.recycle();
        }

        return resizedBitmap;
    }

}
