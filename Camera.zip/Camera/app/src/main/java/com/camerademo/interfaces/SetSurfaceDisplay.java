package com.camerademo.interfaces;

/**
 * 创建人：xy
 * 创建日期：2016/11/10.
 * 功能描述：设置文字与屏幕方向跟随
 */

public interface SetSurfaceDisplay {
    void setDisplay();
}
